package com.example.my_private_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
