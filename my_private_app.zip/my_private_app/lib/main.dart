import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyPrivateApp());
}

class MyPrivateApp extends StatelessWidget {
  const MyPrivateApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Private Safe Vault',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.indigo,
        scaffoldBackgroundColor: const Color(0xFF121212),
        colorScheme: const ColorScheme.dark(
          primary: Colors.indigoAccent,
          secondary: Colors.tealAccent,
        ),
      ),
      home: const AuthenticationScreen(),
    );
  }
}

// ==========================================
// 1. AUTHENTICATION (LOCK SCREEN)
// ==========================================
class AuthenticationScreen extends StatefulWidget {
  const AuthenticationScreen({super.key});

  @override
  State<AuthenticationScreen> createState() => _AuthenticationScreenState();
}

class _AuthenticationScreenState extends State<AuthenticationScreen> {
  final TextEditingController _pinController = TextEditingController();
  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  String _storedPin = "1234";
  String _errorMessage = "";

  @override
  void initState() {
    super.initState();
    _loadPin();
  }

  Future<void> _loadPin() async {
    String? pin = await _storage.read(key: "user_pin");
    if (pin == null) {
      await _storage.write(key: "user_pin", value: "1234");
    } else {
      setState(() {
        _storedPin = pin;
      });
    }
  }

  void _verifyPin() {
    if (_pinController.text == _storedPin) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const MainDashboardScreen()),
      );
    } else {
      setState(() {
        _errorMessage = "Incorrect PIN! Please try again.";
      });
      _pinController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.security, size: 80, color: Colors.indigoAccent),
              const SizedBox(height: 20),
              const Text(
                "Private Vault",
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const Text("Enter PIN to Access (Default: 1234)", style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 30),
              TextField(
                controller: _pinController,
                obscureText: true,
                keyboardType: TextInputType.number,
                maxLength: 4,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 24, letterSpacing: 8),
                decoration: InputDecoration(
                  counterText: "",
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  filled: true,
                  fillColor: Colors.grey[900],
                ),
              ),
              const SizedBox(height: 20),
              if (_errorMessage.isNotEmpty)
                Text(_errorMessage, style: const TextStyle(color: Colors.redAccent)),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _verifyPin,
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(50),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: const Text("UNLOCK", style: TextStyle(fontSize: 18)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==========================================
// 2. MAIN DASHBOARD & NAVIGATION
// ==========================================
class MainDashboardScreen extends StatefulWidget {
  const MainDashboardScreen({super.key});

  @override
  State<MainDashboardScreen> createState() => _MainDashboardScreenState();
}

class _MainDashboardScreenState extends State<MainDashboardScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    const EncryptedNotesTab(),
    const PrivateFilesTab(),
    const LocalAiTab(),
    const SettingsTab(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Secure Personal Safe"),
        actions: [
          IconButton(
            icon: const Icon(Icons.lock),
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const AuthenticationScreen()),
              );
            },
          )
        ],
      ),
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.indigoAccent,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.lock_clock), label: "Notes"),
          BottomNavigationBarItem(icon: Icon(Icons.folder_special), label: "Files"),
          BottomNavigationBarItem(icon: Icon(Icons.psychology), label: "AI Chat"),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: "Settings"),
        ],
      ),
    );
  }
}

// ==========================================
// 3. TAB 1: ENCRYPTED NOTES & DATA
// ==========================================
class EncryptedNotesTab extends StatefulWidget {
  const EncryptedNotesTab({super.key});

  @override
  State<EncryptedNotesTab> createState() => _EncryptedNotesTabState();
}

class _EncryptedNotesTabState extends State<EncryptedNotesTab> {
  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  final TextEditingController _noteController = TextEditingController();
  List<Map<String, String>> _notes = [];

  @override
  void initState() {
    super.initState();
    _loadNotes();
  }

  Future<void> _loadNotes() async {
    String? rawData = await _storage.read(key: "user_notes");
    if (rawData != null && rawData.isNotEmpty) {
      List<String> entries = rawData.split("|||");
      setState(() {
        _notes = entries.map((e) => {"text": e}).toList();
      });
    }
  }

  Future<void> _addNote() async {
    if (_noteController.text.trim().isEmpty) return;
    setState(() {
      _notes.add({"text": _noteController.text});
    });
    String saveString = _notes.map((e) => e["text"]).join("|||");
    await _storage.write(key: "user_notes", value: saveString);
    _noteController.clear();
    if (mounted) Navigator.pop(context);
  }

  void _showAddDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Add Private Note"),
        content: TextField(
          controller: _noteController,
          maxLines: 4,
          decoration: const InputDecoration(hintText: "Enter secret text/passwords..."),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Cancel")),
          ElevatedButton(onPressed: _addNote, child: const Text("Save")),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _notes.isEmpty
          ? const Center(child: Text("No encrypted notes yet.", style: TextStyle(color: Colors.grey)))
          : ListView.builder(
              itemCount: _notes.length,
              itemBuilder: (context, index) {
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ListTile(
                    leading: const Icon(Icons.key, color: Colors.tealAccent),
                    title: Text(_notes[index]["text"] ?? ""),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete, color: Colors.redAccent),
                      onPressed: () async {
                        setState(() {
                          _notes.removeAt(index);
                        });
                        String saveString = _notes.map((e) => e["text"]).join("|||");
                        await _storage.write(key: "user_notes", value: saveString);
                      },
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddDialog,
        child: const Icon(Icons.add),
      ),
    );
  }
}

// ==========================================
// 4. TAB 2: PRIVATE FILES MANAGER
// ==========================================
class PrivateFilesTab extends StatelessWidget {
  const PrivateFilesTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("Secure Vault Files", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          const Text("Files stored here are protected from system scanners.", style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 20),
          Expanded(
            child: GridView.count(
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              children: [
                _buildFolderCard(context, "Documents", Icons.description, "0 Files"),
                _buildFolderCard(context, "Photos", Icons.image, "0 Files"),
                _buildFolderCard(context, "Backups", Icons.backup, "Protected"),
                _buildFolderCard(context, "Archives", Icons.archive, "Encrypted"),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildFolderCard(BuildContext context, String title, IconData icon, String subtitle) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: () {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("$title folder access enabled.")),
          );
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: Colors.indigoAccent),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 5),
            Text(subtitle, style: const TextStyle(color: Colors.grey, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// 5. TAB 3: LOCAL AI ASSISTANT
// ==========================================
class LocalAiTab extends StatefulWidget {
  const LocalAiTab({super.key});

  @override
  State<LocalAiTab> createState() => _LocalAiTabState();
}

class _LocalAiTabState extends State<LocalAiTab> {
  final TextEditingController _chatController = TextEditingController();
  final List<Map<String, String>> _messages = [
    {"role": "ai", "text": "Hello! I am your private offline assistant. How can I help you today?"}
  ];

  void _sendMessage() {
    if (_chatController.text.trim().isEmpty) return;
    String userText = _chatController.text;
    setState(() {
      _messages.add({"role": "user", "text": userText});
      _chatController.clear();
    });

    // Simulated local AI logic response
    Future.delayed(const Duration(milliseconds: 600), () {
      setState(() {
        _messages.add({
          "role": "ai",
          "text": "Your query '$userText' processed securely on-device."
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: _messages.length,
            itemBuilder: (context, index) {
              bool isUser = _messages[index]["role"] == "user";
              return Align(
                alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: isUser ? Colors.indigoAccent : Colors.grey[800],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(_messages[index]["text"] ?? ""),
                ),
              );
            },
          ),
        ),
        Container(
          padding: const EdgeInsets.all(8),
          color: Colors.grey[900],
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _chatController,
                  decoration: const InputDecoration(
                    hintText: "Ask AI Assistant...",
                    border: InputBorder.none,
                  ),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.send, color: Colors.indigoAccent),
                onPressed: _sendMessage,
              )
            ],
          ),
        )
      ],
    );
  }
}

// ==========================================
// 6. TAB 4: SETTINGS & SECURITY
// ==========================================
class SettingsTab extends StatelessWidget {
  const SettingsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final FlutterSecureStorage storage = const FlutterSecureStorage();
    final TextEditingController newPinController = TextEditingController();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        ListTile(
          leading: const Icon(Icons.lock_reset, color: Colors.indigoAccent),
          title: const Text("Change PIN"),
          subtitle: const Text("Update access code"),
          onTap: () {
            showDialog(
              context: context,
              builder: (context) => AlertDialog(
                title: const Text("Change Access PIN"),
                content: TextField(
                  controller: newPinController,
                  keyboardType: TextInputType.number,
                  maxLength: 4,
                  decoration: const InputDecoration(hintText: "Enter new 4-digit PIN"),
                ),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(context), child: const Text("Cancel")),
                  ElevatedButton(
                    onPressed: () async {
                      if (newPinController.text.length == 4) {
                        await storage.write(key: "user_pin", value: newPinController.text);
                        if (context.mounted) {
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text("PIN Updated Successfully!")),
                          );
                        }
                      }
                    },
                    child: const Text("Save"),
                  ),
                ],
              ),
            );
          },
        ),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.security, color: Colors.tealAccent),
          title: const Text("Security Level"),
          subtitle: const Text("AES-256 Local Encryption Active"),
        ),
      ],
    );
  };
}